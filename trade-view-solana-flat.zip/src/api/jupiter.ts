export interface TokenPrice {
  id: string;
  mintSymbol: string;
  price: number;
}

export async function fetchTokenPrices(tokenIds: string[] = ["SOL", "USDC"]): Promise<TokenPrice[]> {
  const ids = tokenIds.join(",");
  const res = await fetch(`https://quote-api.jup.ag/v6/price?ids=${ids}`);
  const json = await res.json();
  return Object.entries(json.data).map(([id, data]: any) => ({
    id,
    mintSymbol: data.mintSymbol,
    price: data.price,
  }));
}
