import React, { useEffect, useState } from "react";
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from "recharts";

interface HistoryData {
  time: string;
  price: number;
}

export const TokenPriceChart: React.FC<{ tokenId?: string }> = ({ tokenId = "SOL" }) => {
  const [data, setData] = useState<HistoryData[]>([]);

  useEffect(() => {
    async function fetchHistory() {
      const res = await fetch(`https://public-api.jup.ag/historical/v1/price?id=${tokenId}`);
      const json = await res.json();
      const formatted = json.data.map((item: any) => ({
        time: new Date(item.timestamp * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        price: item.price,
      }));
      setData(formatted);
    }

    fetchHistory();
  }, [tokenId]);

  return (
    <div className="mt-6">
      <h2 className="text-lg font-bold mb-2">Grafik Harga {tokenId}</h2>
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="time" minTickGap={20} />
          <YAxis domain={['auto', 'auto']} />
          <Tooltip />
          <Line type="monotone" dataKey="price" stroke="#8884d8" dot={false} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};
