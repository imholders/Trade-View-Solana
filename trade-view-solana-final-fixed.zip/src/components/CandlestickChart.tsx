import React, { useEffect, useState } from "react";
import Chart from "react-apexcharts";

interface CandlestickData {
  x: string;
  y: [number, number, number, number]; // [open, high, low, close]
}

const CandlestickChart: React.FC<{ tokenId?: string }> = ({ tokenId = "SOL" }) => {
  const [series, setSeries] = useState([{ data: [] as CandlestickData[] }]);

  useEffect(() => {
    async function fetchCandles() {
      const res = await fetch(`https://public-api.jup.ag/historical/v1/candles?id=${tokenId}&interval=5m&span=6h`);
      const json = await res.json();
      const data = json.data.map((item: any) => ({
        x: new Date(item.timestamp * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        y: [item.open, item.high, item.low, item.close],
      }));
      setSeries([{ data }]);
    }

    fetchCandles();
  }, [tokenId]);

  return (
    <div className="mt-6">
      <h2 className="text-lg font-bold mb-2">Candlestick Chart {tokenId}</h2>
      <Chart
        options={{ chart: { type: "candlestick" }, xaxis: { type: "category" } }}
        series={series}
        type="candlestick"
        height={350}
      />
    </div>
  );
};

export default CandlestickChart;
