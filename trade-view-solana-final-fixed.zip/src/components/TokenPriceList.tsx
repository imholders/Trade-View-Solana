import React, { useEffect, useState } from "react";
import { fetchTokenPrices, TokenPrice } from "../api/jupiter";

const TokenPriceList: React.FC = () => {
  const [prices, setPrices] = useState<TokenPrice[]>([]);

  useEffect(() => {
    const interval = setInterval(async () => {
      const data = await fetchTokenPrices(["SOL", "USDC", "BONK"]);
      setPrices(data);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="mt-4">
      <h2 className="text-xl font-bold mb-2">Harga Token Real-time (Jupiter)</h2>
      <ul className="space-y-2">
        {prices.map((token) => (
          <li key={token.id} className="text-sm">
            {token.mintSymbol}: <span className="font-semibold">${token.price.toFixed(4)}</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TokenPriceList;
