import React from "react";
import { WalletContextProvider, WalletButton } from "./solana/WalletProvider";
import Home from "./pages/Home";

function App() {
  return (
    <WalletContextProvider>
      <div className="p-4">
        <WalletButton />
        <Home />
      </div>
    </WalletContextProvider>
  );
}

export default App;
