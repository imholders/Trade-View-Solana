import React from "react";
import TokenPriceList from "../components/TokenPriceList";
import { TokenPriceChart } from "../components/TokenPriceChart";

const Home: React.FC = () => {
  return (
    <div>
      <TokenPriceList />
      <TokenPriceChart tokenId="SOL" />
    </div>
  );
};

export default Home;
