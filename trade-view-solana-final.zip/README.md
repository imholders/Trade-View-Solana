# Trade View Solana

Aplikasi visualisasi harga token real-time di jaringan Solana menggunakan data dari Jupiter Aggregator dan integrasi wallet Solana.

## Fitur
- Harga token real-time
- Grafik historis token
- Integrasi Wallet Phantom & Backpack

## Cara Jalanin
```bash
npm install
npm run dev
```

## Lisensi
MIT
